# Repository Instructions for GitHub Copilot

## Overview

This repository contains a **Vite 8** React frontend and an Express backend.
The UI uses a **plugin architecture**: each folder under `web‑ui/src/plugins`
defines a route that is loaded dynamically at runtime.  The backend is kept
minimal, exposing a `/api/health` endpoint.  The project assumes the
developer is using VS Code with GitHub Copilot.

## Stack

### Frontend

- React 19 with TypeScript
- Vite 8 as the build tool and dev server (requires Node.js 20.19+【680582402486350†L230-L236】)
- `@vitejs/plugin-react` v6 for React Refresh (uses Oxc rather than Babel)
- React Router for routing
- Plugin system using `import.meta.glob` and `React.lazy` to load each
  plugin lazily

### Backend

- Node.js with TypeScript
- Express for HTTP routing
- Minimal structure: routes defined in `web‑svr/src/routes`

## Coding rules

- **Use TypeScript** for all new files; avoid plain JavaScript.
- **Follow the plugin architecture**:
  - Each plugin lives under `web‑ui/src/plugins/<name>/index.tsx` and exports
    a default React component.  The component is mounted at `/<name>`.
  - Do not modify the core router when adding a new plugin.  Instead, create
    a new folder under `plugins` and provide an `index.tsx` file.
  - Keep plugin components focused; avoid business logic and API calls.
- **Main router** resides in `web‑ui/src/App.tsx` and uses
  `import.meta.glob('./plugins/**/index.tsx')` to discover plugins.  When
  extending routing, reuse this dynamic pattern rather than hard‑coding
  imports.
- **Backend routes** should remain thin: controllers live in
  `web‑svr/src/routes` and should forward business logic to services (not yet
  implemented in this scaffold).
- **Node version**: rely on Node 20.19+ to support Vite 8’s ESM‑only
  distribution【680582402486350†L230-L236】.
- **Avoid unnecessary dependencies**.  Vite 8 includes built‑in support for
  tsconfig path aliases and React Refresh【680582402486350†L247-L253】; do not add
  redundant plugins.
- **Imports** should respect path aliases defined in `tsconfig.json` (`@/`
  for `src`).
- **Add documentation** when introducing new plugins or API endpoints.

## File conventions

- `web‑ui/src/main.tsx` creates the React root and imports `App.tsx`.
- `web‑ui/src/App.tsx` sets up routing with dynamic plugin discovery.
- Each plugin exports a default component from `index.tsx` and may contain
  other files if needed.
- `web‑svr/src/index.ts` starts the Express server and uses the router from
  `web‑svr/src/app.ts`.
- Environment variables meant for the frontend must be prefixed with
  `VITE_` and defined in `.env` or `.env.local`.  A sample file
  `.env.example` is provided.

## Quality bar

- Keep functions small and focused.
- Use meaningful names; avoid abbreviations.
- Add light comments only when the intent is not obvious.
- Avoid leaving `TODO` without follow‑up; if a task is deferred, explain why.
- Ensure that new plugins do not break existing routes.
