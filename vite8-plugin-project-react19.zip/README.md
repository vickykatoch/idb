# Vite 8 Plugin Architecture Starter

This repository contains a full‑stack project scaffold with a **Vite 8** powered
React frontend and an Express backend.  The focus of the UI is a flexible
**plugin architecture**: features can be encapsulated in their own folders
under `web‑ui/src/plugins`, and the main app will discover and load them at
runtime using Vite’s dynamic import API (`import.meta.glob`).  The backend is a
minimal Express server with TypeScript support.

## Getting started

1. **Install dependencies** from the root.  You should use
   Node.js 20.19 or later as required by Vite 8【680582402486350†L230-L236】:

   ```bash
   cd vite8-plugin-project
   npm install
   ```

2. **Run both the client and server** concurrently:

   ```bash
   npm run dev
   ```

   This runs `web‑ui` on port 5173 and `web‑svr` on port 3000.  You can also
   start them individually via `npm run dev:ui` and `npm run dev:svr`.

3. Open `http://localhost:5173` in your browser.  You will see the home page
   listing the available plugins.

## Plugin architecture

The UI’s plugin system allows new features to be added without modifying the
core router.  Each plugin is a folder under `web‑ui/src/plugins/<name>` with
an `index.tsx` file exporting a React component.  The main router uses
`import.meta.glob('./plugins/**/index.tsx')` to discover all plugins and
creates a route for each folder automatically.  The route path is based on
the folder name (e.g. `src/plugins/hello` becomes `/hello`).  Plugins are
loaded lazily via `React.lazy` for optimal performance.

### Adding a new plugin

1. Create a new folder in `web‑ui/src/plugins` with your plugin name,
   for example `web‑ui/src/plugins/news`.
2. Add an `index.tsx` file exporting a React component that represents the
   plugin page.  The component will be mounted at `/news`.
3. Optionally add static assets or other files within your plugin folder.

When you restart the dev server, the new route will appear automatically.

## Project structure

```
vite8-plugin-project/
├── README.md           # this file
├── .gitignore          # ignores node_modules, build outputs, etc.
├── .env.example        # sample environment variables for client and server
├── package.json        # root workspace manifest
├── tsconfig.base.json  # shared TypeScript configuration
├── .github/            # custom instructions for AI coding assistants
├── web-ui/             # React frontend with Vite 8
│   ├── package.json
│   ├── tsconfig.json
│   ├── vite.config.ts
│   ├── index.html
│   └── src/
│       ├── main.tsx
│       ├── App.tsx
│       ├── pages/
│       │   └── Home.tsx
│       └── plugins/
│           ├── hello/
│           │   └── index.tsx
│           └── about/
│               └── index.tsx
└── web-svr/            # Express backend with TypeScript
    ├── package.json
    ├── tsconfig.json
    └── src/
        ├── index.ts
        ├── app.ts
        └── routes/
            └── index.ts
```

## Development notes

- **Node version:** Vite 8 is distributed as ES modules and requires
  Node.js 20.19+ or 22.12+【680582402486350†L230-L236】.  Make sure your runtime
  matches these versions.
- **React plugin:** This project uses `@vitejs/plugin-react` v6, which relies
  on Oxc instead of Babel and has built‑in React Refresh support【680582402486350†L247-L253】.
- **tsconfig paths:** The Vite configuration enables `resolve.tsconfigPaths`
  so you can define path aliases in `tsconfig.json` and import modules using
  `@/` prefixes.
- **Forward console:** The dev server forwards browser console logs to the
  terminal to aid debugging in AI pair‑programming scenarios【680582402486350†L258-L262】.
