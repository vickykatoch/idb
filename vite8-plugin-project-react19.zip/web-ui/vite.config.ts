import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// Vite configuration for the web UI
export default defineConfig({
  plugins: [react()],
  resolve: {
    tsconfigPaths: true,
  },
  server: {
    // Forward browser console logs to the terminal, useful for AI debugging
    forwardConsole: true,
  },
});