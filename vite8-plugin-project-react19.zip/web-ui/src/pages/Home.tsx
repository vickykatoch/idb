import React from 'react';
import { Link } from 'react-router-dom';

// Discover plugin names for navigation.  We import nothing from the
// modules themselves, just get their keys.  The glob pattern must be
// relative to this file, so we navigate up into the plugins directory.
const modules = import.meta.glob('../plugins/**/index.tsx');
const pluginLinks = Object.keys(modules).map((path) => {
  const match = /\.\.\/plugins\/(.+?)\/index\.tsx$/.exec(path);
  const name = match ? match[1] : path;
  return { name, path: `/${name}` };
});

export default function Home() {
  return (
    <div>
      <h1>Home</h1>
      <p>This is the home page.  The following plugins are available:</p>
      <ul>
        {pluginLinks.map(({ name, path }) => (
          <li key={name}>
            <Link to={path}>{name}</Link>
          </li>
        ))}
      </ul>
    </div>
  );
}