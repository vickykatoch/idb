import React from 'react';

export default function HelloPlugin() {
  return (
    <div>
      <h2>Hello Plugin</h2>
      <p>This is a sample plugin demonstrating the plugin architecture.  It is
        loaded lazily when you navigate to <code>/hello</code>.</p>
    </div>
  );
}