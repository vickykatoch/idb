import React from 'react';

export default function AboutPlugin() {
  return (
    <div>
      <h2>About Plugin</h2>
      <p>This plugin demonstrates how to add another plugin.  You can create
        your own plugins by adding new folders under <code>src/plugins</code>
        with an <code>index.tsx</code> file exporting a React component.</p>
    </div>
  );
}