import React, { Suspense } from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';

// Import the home page
import Home from './pages/Home.tsx';

// Dynamically import all plugins under src/plugins.  Each key in the
// returned object is the file path and the value is a function that
// returns a promise resolving to the module.  See Vite docs for details.
const modules = import.meta.glob('./plugins/**/index.tsx');

// Build plugin routes by mapping each plugin folder to a route.  The
// path is derived from the folder name (e.g. './plugins/hello/index.tsx'
// → '/hello') and the component is loaded lazily using React.lazy.
const pluginRoutes = Object.entries(modules).map(([path, loader]) => {
  // Extract the plugin name between 'plugins/' and '/index.tsx'
  const match = /\.\/plugins\/(.+?)\/index\.tsx$/.exec(path);
  const name = match ? match[1] : path;
  // Cast the loader to the correct type for React.lazy
  const Component = React.lazy(loader as unknown as () => Promise<{ default: React.ComponentType<any> }>);
  return { path: `/${name}`, Component };
});

export default function App() {
  return (
    <BrowserRouter>
      {/* Suspense boundary to show fallback while lazy components load */}
      <Suspense fallback={<div>Loading...</div>}>
        <Routes>
          {/* Home route */}
          <Route path="/" element={<Home />} />
          {/* Dynamically generated plugin routes */}
          {pluginRoutes.map(({ path, Component }) => (
            <Route key={path} path={path} element={<Component />} />
          ))}
          {/* Catch‑all route for 404s */}
          <Route path="*" element={<div>Not Found</div>} />
        </Routes>
      </Suspense>
    </BrowserRouter>
  );
}