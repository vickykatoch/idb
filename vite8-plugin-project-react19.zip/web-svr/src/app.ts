import express from 'express';
import routes from './routes/index.js';

const app = express();

// JSON parsing middleware
app.use(express.json());

// Mount API routes under /api
app.use('/api', routes);

export default app;