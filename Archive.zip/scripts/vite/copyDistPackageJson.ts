/** biome-ignore-all lint/suspicious/noExplicitAny: false positive */
import fs from 'node:fs';
import path from 'node:path';
import type { Plugin } from 'vite';

type ExportsEntry = {
	types?: string;
	import?: string;
	require?: string;
	default?: string;
};
type Fields = {
	name?: string;
	version?: string;
	main?: string;
	module?: string;
	types?: string;
};

type DistPackageJsonOptions = {
	/**
	 * Absolute path to the library folder containing package.json
	 * e.g. __dirname from libs/utils/vite.config.ts
	 */
	libDir: string;

	/**
	 * Absolute path to dist output folder for this lib
	 * e.g. path.resolve(__dirname, "../../dist/utils")
	 */
	distDir: string;

	/**
	 * Optional: override dist package "name" / "version"
	 * Default: keep from source package.json
	 */
	fields?: Fields;

	/**
	 * Optional: how to build dist exports.
	 * If not provided, we will:
	 *  - use source package.json exports if present
	 *  - else keep a minimal "." export only
	 */
	exports?:
		| Record<string, ExportsEntry>
		| ((ctx: { srcPkg: any; distDir: string }) => Record<string, ExportsEntry>);

	/**
	 * Whether to include dependencies/peerDependencies from source package.json.
	 * Defaults: true for peerDependencies, false for dependencies.
	 */
	includeDependencies?: boolean;
	includePeerDependencies?: boolean;

	/**
	 * Extra fields to copy from source package.json into dist package.json
	 * e.g. ["description","license","repository","keywords"]
	 */
	copyFields?: string[];
};

function readJson(filePath: string) {
	return JSON.parse(fs.readFileSync(filePath, 'utf8'));
}

function writeJson(filePath: string, obj: any) {
	fs.mkdirSync(path.dirname(filePath), { recursive: true });
	fs.writeFileSync(filePath, `${JSON.stringify(obj, null, 2)}\n`);
}

function pickFields(src: any, fields: string[]) {
	const out: any = {};
	for (const f of fields) {
		if (src[f] !== undefined) out[f] = src[f];
	}
	return out;
}

export function copyDistPackageJson(opts: DistPackageJsonOptions): Plugin {
	return {
		name: 'copy-dist-package-json',
		apply: 'build',
		closeBundle() {
			const srcPkgPath = path.resolve(opts.libDir, 'package.json');
			const outPkgPath = path.resolve(opts.distDir, 'package.json');

			const srcPkg = readJson(srcPkgPath);

			const copyFields = opts.copyFields ?? [
				'description',
				'license',
				'author',
				'repository',
				'homepage',
				'bugs',
				'keywords',
				'funding',
			];

			// Default dist entrypoints (works great with dist/<lib>/{esm,cjs,types})
			// You can override by providing opts.exports
			const defaultExports: Record<string, ExportsEntry> = srcPkg.exports ?? {
				'.': {
					types: './types/index.d.ts',
					import: './esm/index.js',
					require: './cjs/index.cjs',
				},
			};

			const resolvedExports =
				typeof opts.exports === 'function'
					? opts.exports({ srcPkg, distDir: opts.distDir })
					: (opts.exports ?? defaultExports);

			const distPkg: any = {
				name: opts.fields?.name ?? srcPkg.name,
				version: opts.fields?.version ?? srcPkg.version,
				sideEffects: srcPkg.sideEffects ?? false,
				// Standard entrypoints matching the default exports layout
				main: opts.fields?.main ?? './cjs/index.cjs',
				module: opts.fields?.module ?? './esm/index.js',
				types: opts.fields?.types ?? './types/index.d.ts',
				...pickFields(srcPkg, copyFields),

				// Include only what you actually want in dist.
				...(opts.includeDependencies ? { dependencies: srcPkg.dependencies } : {}),
				...((opts.includePeerDependencies ?? true)
					? {
							peerDependencies: srcPkg.peerDependencies,
							peerDependenciesMeta: srcPkg.peerDependenciesMeta,
						}
					: {}),

				exports: resolvedExports,
			};

			// Clean undefined values
			for (const k of Object.keys(distPkg)) {
				if (distPkg[k] === undefined) delete distPkg[k];
			}

			writeJson(outPkgPath, distPkg);
			// eslint-disable-next-line no-console
			console.log(`[copy-dist-package-json] wrote ${path.relative(process.cwd(), outPkgPath)}`);
		},
	};
}
