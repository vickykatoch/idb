export function isBoolean(v: unknown): v is boolean {
	return typeof v === 'boolean';
}

export function toBoolean(v: unknown, defaultValue = false): boolean {
	if (typeof v === 'boolean') return v;
	if (typeof v === 'string') {
		const s = v.trim().toLowerCase();
		if (s === 'true') return true;
		if (s === 'false') return false;
	}
	if (typeof v === 'number') return v !== 0;
	return defaultValue;
}
