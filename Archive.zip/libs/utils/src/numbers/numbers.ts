export function clamp(n: number, min: number, max: number): number {
	return Math.min(max, Math.max(min, n));
}

export function isFiniteNumber(v: unknown): v is number {
	return typeof v === 'number' && Number.isFinite(v);
}

export function roundTo(n: number, decimals: number): number {
	const p = 10 ** decimals;
	return Math.round(n * p) / p;
}
