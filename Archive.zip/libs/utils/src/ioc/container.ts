import { CircularDependencyError, ServiceNotRegisteredError } from './errors';
import type { Lifetime } from './lifetime';
import type { Token } from './token';

type Factory<T> = (c: Container) => T;

type Registration<T> = {
	lifetime: Lifetime;
	factory: Factory<T>;
	singleton?: T;
	description: string;
};

export class Container {
	private readonly regs = new Map<symbol, Registration<unknown>>();
	private readonly resolving: string[] = [];

	register<T>(
		token: Token<T>,
		factory: Factory<T>,
		opts: { lifetime?: Lifetime; description?: string } = {},
	): this {
		const description = opts.description ?? token.description ?? 'Token';
		this.regs.set(token, {
			lifetime: opts.lifetime ?? 'transient',
			factory,
			description,
		});
		return this;
	}

	registerValue<T>(token: Token<T>, value: T, description?: string): this {
		return this.register(token, () => value, { lifetime: 'singleton', description });
	}

	resolve<T>(token: Token<T>): T {
		const reg = this.regs.get(token) as Registration<T> | undefined;
		const desc = token.description ?? 'Token';

		if (!reg) throw new ServiceNotRegisteredError(desc);

		// circular detection
		if (this.resolving.includes(reg.description)) {
			throw new CircularDependencyError([...this.resolving, reg.description]);
		}

		if (reg.lifetime === 'singleton') {
			if (reg.singleton !== undefined) return reg.singleton;
			this.resolving.push(reg.description);
			try {
				const created = reg.factory(this);
				reg.singleton = created;
				return created;
			} finally {
				this.resolving.pop();
			}
		}

		this.resolving.push(reg.description);
		try {
			return reg.factory(this);
		} finally {
			this.resolving.pop();
		}
	}

	has(token: Token<unknown>): boolean {
		return this.regs.has(token);
	}
}
