export type Lifetime = 'singleton' | 'transient';
