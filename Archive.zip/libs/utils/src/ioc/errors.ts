export class IoCError extends Error {
	override name = 'IoCError';
}

export class ServiceNotRegisteredError extends IoCError {
	constructor(tokenDescription: string) {
		super(`Service not registered: ${tokenDescription}`);
		this.name = 'ServiceNotRegisteredError';
	}
}

export class CircularDependencyError extends IoCError {
	constructor(chain: string[]) {
		super(`Circular dependency detected: ${chain.join(' -> ')}`);
		this.name = 'CircularDependencyError';
	}
}
