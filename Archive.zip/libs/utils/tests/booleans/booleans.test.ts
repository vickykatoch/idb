import { describe, expect, it } from 'vitest';
import { isBoolean, toBoolean } from '../../src/booleans';

describe('isBoolean', () => {
	it('should return true for boolean values', () => {
		expect(isBoolean(true)).toBe(true);
		expect(isBoolean(false)).toBe(true);
	});

	it('should return false for non-boolean values', () => {
		expect(isBoolean('true')).toBe(false);
		expect(isBoolean(1)).toBe(false);
		expect(isBoolean(null)).toBe(false);
		expect(isBoolean(undefined)).toBe(false);
	});
});

describe('toBoolean', () => {
	it('should return the same boolean value if input is boolean', () => {
		expect(toBoolean(true)).toBe(true);
		expect(toBoolean(false)).toBe(false);
	});

	it('should convert string "true" to true and "false" to false', () => {
		expect(toBoolean('true')).toBe(true);
		expect(toBoolean('false')).toBe(false);
	});

	it('should trim and convert string values correctly', () => {
		expect(toBoolean('  true  ')).toBe(true);
		expect(toBoolean('  false  ')).toBe(false);
	});

	it('should convert non-zero numbers to true and zero to false', () => {
		expect(toBoolean(1)).toBe(true);
		expect(toBoolean(0)).toBe(false);
	});

	it('should return default value for unsupported types', () => {
		expect(toBoolean(null, true)).toBe(true);
		expect(toBoolean(undefined, false)).toBe(false);
	});
});
