import path from 'node:path';
import { defineConfig } from 'vite';
import dts from 'vite-plugin-dts';
import { copyDistPackageJson } from '../../scripts/vite/copyDistPackageJson';

const entry = path.resolve(__dirname, 'src/index.ts');
const distDir = path.resolve(__dirname, '../../dist/libs/utils');
const distTypesDir = path.resolve(__dirname, '../../dist/libs/utils/types');

export default defineConfig({
	plugins: [
		dts({
			entryRoot: 'src',
			outDir: distTypesDir,
			// this helps generate a top-level types entry if you want it
			insertTypesEntry: true,
		}),
		copyDistPackageJson({
			libDir: __dirname,
			distDir,
			fields: {
				main: './index.cjs.js',
				module: './index.es.js',
				types: './types/index.d.ts',
			},
			copyFields: ['description', 'license', 'repository', 'keywords'],
			includeDependencies: false,
			includePeerDependencies: true,
			exports: {
				'.': {
					import: './index.es.js',
					require: './index.cjs.js',
					types: './types/index.d.ts',
				},
				'./numbers': {
					types: './types/numbers/index.d.ts',
					import: './numbers/index.js',
					require: './numbers/index.cjs',
				},
				'./strings': {
					types: './types/strings/index.d.ts',
					import: './strings/index.js',
					require: './strings/index.cjs',
				},
				'./booleans': {
					types: './types/booleans/index.d.ts',
					import: './booleans/index.js',
					require: './booleans/index.cjs',
				},
				'./ioc': {
					types: './types/ioc/index.d.ts',
					import: './ioc/index.js',
					require: './ioc/index.cjs',
				},
			},
		}),
	],
	build: {
		// <-- output at repo root
		outDir: distDir,
		emptyOutDir: true,
		lib: {
			entry: entry,
			name: 'utils',
			formats: ['es', 'cjs'],
			fileName: (format) => `index.${format}.js`,
		},
		// keep folder structure so subpath exports work nicely (numbers/, strings/, ioc/, etc.)
		rollupOptions: {
			output: {
				preserveModules: true,
				preserveModulesRoot: 'src',
				entryFileNames: (chunk) => `${chunk.name}.[format].js`,
			},
		},

		sourcemap: true,
	},
});
