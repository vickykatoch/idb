# reactv17-scf
## In your Angular 2 systemjs.config.js:

`System.config({
  map: {
    "@avam/utils": "/dist/utils/system"
  },
  packages: {
    "@avam/utils": {
      defaultExtension: "js"
    }
  }
});`
## Then Angular code:
import { clamp } from "@avam/utils/numbers";
## SystemJS resolves:
/dist/utils/system/numbers/index.js