import { defineWorkspace } from 'vitest/config';

export default defineWorkspace(['apps/*', 'libs/*', 'plugins/*']);
