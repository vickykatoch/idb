import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import App from './App';

const rootElem = document.getElementById('root');
// biome-ignore lint/style/noNonNullAssertion: false positive
createRoot(rootElem!).render(
	<StrictMode>
		<App />
	</StrictMode>,
);
