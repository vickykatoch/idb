import { toBoolean } from '@avam/utils';
import { useEffect } from 'react';
export default function App() {
	useEffect(() => {
		console.log('IsTrue : ', toBoolean('true'));
	}, []);
	return <div>Hello, World!</div>;
}
