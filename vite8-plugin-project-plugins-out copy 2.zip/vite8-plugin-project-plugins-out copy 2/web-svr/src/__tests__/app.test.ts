import { describe, it, expect } from 'vitest';
import request from 'supertest';
import app from '../app.js';

describe('app', () => {
  it('parses JSON request bodies', async () => {
    const res = await request(app)
      .post('/api/health')
      .send({ test: true })
      .set('Content-Type', 'application/json');
    // POST is not defined, so we expect 404, but body parsing should not error
    expect(res.status).not.toBe(500);
  });

  it('mounts routes under /api', async () => {
    const res = await request(app).get('/api/health');
    expect(res.status).toBe(200);
  });

  it('returns 404 for non-api paths', async () => {
    const res = await request(app).get('/nonexistent');
    expect(res.status).toBe(404);
  });
});
