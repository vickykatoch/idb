import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';

describe('server startup', () => {
  const originalPort = process.env.PORT;

  beforeEach(() => {
    vi.resetModules();
  });

  afterEach(() => {
    if (originalPort !== undefined) {
      process.env.PORT = originalPort;
    } else {
      delete process.env.PORT;
    }
  });

  it('defaults to port 3000 when PORT is not set', async () => {
    delete process.env.PORT;
    const listenMock = vi.fn((_port: number, cb: () => void) => {
      cb();
      return {} as any;
    });
    vi.doMock('../app.js', () => ({
      default: { listen: listenMock },
    }));

    await import('../index.js');
    expect(listenMock).toHaveBeenCalledWith(3000, expect.any(Function));
  });

  it('uses PORT from environment when set', async () => {
    process.env.PORT = '4000';
    const listenMock = vi.fn((_port: number, cb: () => void) => {
      cb();
      return {} as any;
    });
    vi.doMock('../app.js', () => ({
      default: { listen: listenMock },
    }));

    await import('../index.js');
    expect(listenMock).toHaveBeenCalledWith(4000, expect.any(Function));
  });
});
