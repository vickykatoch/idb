import React from 'react';

/**
 * Example plugin component.  This plugin will be loaded lazily by the
 * main router.  It demonstrates how to define a plugin page without
 * touching the core UI.  To create your own plugin, copy this folder
 * and change the component as needed.  The folder name becomes the
 * route path (e.g. `ui-plugins/hello` → `/hello`).
 */
export default function HelloPlugin() {
  return (
    <div>
      <h2>Hello Plugin</h2>
      <p>
        This is a sample plugin demonstrating the plugin architecture.  It is
        loaded lazily when you navigate to <code>/hello</code>.
      </p>
    </div>
  );
}
