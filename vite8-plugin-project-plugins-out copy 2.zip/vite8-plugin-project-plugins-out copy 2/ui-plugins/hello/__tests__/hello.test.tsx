import { render, screen } from '@testing-library/react';
import { describe, it, expect } from 'vitest';
import HelloPlugin from '../index.tsx';

// Unit test for the Hello plugin.  This ensures the plugin renders
// the expected heading and description.  Vitest will run this file
// because it matches the `*.test.tsx` pattern configured in the
// Vite/Vitest config.

describe('HelloPlugin', () => {
  it('renders the heading and paragraph', () => {
    render(<HelloPlugin />);
    // Check that the heading appears
    expect(screen.getByRole('heading', { name: /Hello Plugin/i })).toBeInTheDocument();
    // Check that the descriptive text appears
    expect(screen.getByText(/sample plugin/i)).toBeInTheDocument();
  });
});
