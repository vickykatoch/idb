import { render, screen } from '@testing-library/react';
import { describe, it, expect } from 'vitest';
import AboutPlugin from '../index.tsx';

describe('AboutPlugin', () => {
  it('renders the heading', () => {
    render(<AboutPlugin />);
    expect(screen.getByRole('heading', { name: /About/i })).toBeInTheDocument();
  });

  it('renders the description text', () => {
    render(<AboutPlugin />);
    expect(screen.getByText(/plugin architecture powered by Vite 8/i)).toBeInTheDocument();
  });
});
