import React from 'react';

/**
 * About plugin.  This page provides information about the application
 * and demonstrates how easy it is to add new routes using the plugin
 * system.  Place any plugin in the `ui-plugins` folder and export a
 * default component from `index.tsx`.
 */
export default function AboutPlugin() {
  return (
    <div>
      <h2>About</h2>
      <p>
        This starter project uses a plugin architecture powered by Vite 8.
        Plugins live outside the main UI project in the `ui-plugins` folder
        and are imported dynamically at runtime.  You can add as many
        plugins as you need without modifying the core router.
      </p>
    </div>
  );
}
