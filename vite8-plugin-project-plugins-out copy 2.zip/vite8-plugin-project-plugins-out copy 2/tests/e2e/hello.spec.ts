import { test, expect } from '@playwright/test';

// Basic end‑to‑end test demonstrating navigation to a plugin page.
// This test navigates to the home page, clicks on the link for the
// "hello" plugin and asserts that the plugin content renders.

test('hello plugin renders via navigation', async ({ page }) => {
  // Navigate to the home page of the UI
  await page.goto('http://localhost:5173/');
  // Click the link to the hello plugin (case‑insensitive)
  await page.getByRole('link', { name: /hello/i }).click();
  // Wait for the heading to appear and verify its text
  await expect(page.getByRole('heading', { level: 2 })).toHaveText('Hello Plugin');
  // Verify the descriptive text appears
  await expect(page.locator('p')).toContainText('sample plugin');
});