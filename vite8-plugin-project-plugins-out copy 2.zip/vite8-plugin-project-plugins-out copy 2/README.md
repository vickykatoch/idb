# Vite 8 Plugin Architecture Starter

This repository contains a full‑stack project scaffold with a **Vite 8** powered
React frontend and an Express backend.  The focus of the UI is a flexible
**plugin architecture**: features can be encapsulated in their own folders
outside of the main UI project.  Plugins live in the top‑level
`ui‑plugins` directory next to `web‑ui` and `web‑svr`.  The main app will
discover and load them at runtime using Vite’s dynamic import API
(`import.meta.glob`), so no manual route registration is required.  The
backend is a minimal Express server with TypeScript support.

## Getting started

1. **Install dependencies** from the root.  You should use
   Node.js 20.19 or later as required by Vite 8【680582402486350†L230-L236】:

   ```bash
   cd vite8-plugin-project
   npm install
   ```

2. **Run both the client and server** concurrently:

   ```bash
   npm run dev
   ```

   This runs `web‑ui` on port 5173 and `web‑svr` on port 3000.  You can also
   start them individually via `npm run dev:ui` and `npm run dev:svr`.

3. Open `http://localhost:5173` in your browser.  You will see the home page
   listing the available plugins.  When you add a new folder under
   `ui‑plugins`, the route will appear automatically without modifying
   the UI project.

## Plugin architecture

The UI’s plugin system allows new features to be added without modifying the
core router.  Each plugin lives in its own folder under the top‑level
`ui‑plugins` directory (parallel to `web‑ui` and `web‑svr`).  A plugin
folder must contain an `index.tsx` file exporting a default React
component.  The main router uses `import.meta.glob('../../ui-plugins/**/index.tsx')`
to discover all plugins and creates a route for each folder automatically.
The route path is based on the folder name (e.g. `ui‑plugins/hello`
becomes `/hello`).  Plugins are loaded lazily via `React.lazy` for
optimal performance.

### Adding a new plugin

1. Create a new folder in `ui‑plugins` with your plugin name, for example
   `ui‑plugins/news`.
2. Inside that folder, add an `index.tsx` file exporting a React component
   that represents the plugin page.  The folder name determines the URL
   path: `ui‑plugins/news` becomes `/news`.
3. Optionally add static assets or other files within your plugin folder.

When you restart the dev server (or run the tests), the new route will
appear automatically.  You do not need to modify `web‑ui` to register
the plugin.

## Project structure

```
vite8-plugin-project/
├── README.md           # this file
├── .gitignore          # ignores node_modules, build outputs, etc.
├── .env.example        # sample environment variables for client and server
├── package.json        # root workspace manifest
├── tsconfig.base.json  # shared TypeScript configuration
├── .github/            # custom instructions for AI coding assistants
├── ui-plugins/         # React plugins loaded dynamically by the UI
│   ├── hello/
│   │   ├── index.tsx   # sample plugin component
│   │   └── hello.test.tsx # unit test for the hello plugin
│   └── about/
│       └── index.tsx   # second sample plugin
├── web-ui/             # React frontend with Vite 8
│   ├── package.json
│   ├── tsconfig.json
│   ├── vite.config.ts
│   ├── index.html
│   └── src/
│       ├── main.tsx
│       ├── App.tsx
│       ├── pages/
│       │   └── Home.tsx
│       ├── setupTests.ts # Vitest setup file
│       └── App.tsx       # Router with dynamic plugin loading
└── web-svr/            # Express backend with TypeScript
    ├── package.json
    ├── tsconfig.json
    └── src/
        ├── index.ts
        ├── app.ts
        └── routes/
            └── index.ts
```

## Development notes

- **Node version:** Vite 8 is distributed as ES modules and requires
  Node.js 20.19+ or 22.12+【680582402486350†L230-L236】.  Make sure your runtime
  matches these versions.
- **React plugin:** This project uses `@vitejs/plugin-react` v6, which relies
  on Oxc instead of Babel and has built‑in React Refresh support【680582402486350†L247-L253】.
- **tsconfig paths:** The Vite configuration enables `resolve.tsconfigPaths`
  so you can define path aliases in `tsconfig.json` and import modules using
  `@/` prefixes.
- **Forward console:** The dev server forwards browser console logs to the
  terminal to aid debugging in AI pair‑programming scenarios【680582402486350†L258-L262】.

## Testing

This project includes both unit tests and end‑to‑end (E2E) tests:

- **Unit tests** are written using [Vitest](https://vitest.dev/), a Vite‑native
  testing framework.  Vitest automatically reuses your Vite config
  (including plugins and aliases)【637288399974810†L271-L279】.  Tests live next to the
  code they cover (e.g. `ui‑plugins/hello/hello.test.tsx`).  Run unit
  tests with:

  ```bash
  npm run test:unit
  ```

- **E2E tests** are written using [Playwright](https://playwright.dev/).  The
  Vue testing guide recommends Playwright as a modern, cross‑browser E2E
  solution with built‑in debuggability【593574544869873†L563-L572】.  Tests live in
  `tests/e2e/` and are executed in headless browsers.  The Playwright
  configuration (`playwright.config.ts`) starts the dev server
  automatically before running the tests.  Run the E2E tests with:

  ```bash
  npm run test:e2e
  ```

You can also run both sets of tests by invoking the default `npm test` script.
