import { render, screen } from '@testing-library/react';
import { describe, it, expect, vi } from 'vitest';
import { MemoryRouter } from 'react-router-dom';
import Home from '../Home.tsx';

// Mock import.meta.glob to return a known set of plugin paths
vi.mock('../../../ui-plugins/**/index.tsx', () => ({}));

// Helper to render Home within a router context
function renderHome() {
  return render(
    <MemoryRouter future={{ v7_startTransition: true, v7_relativeSplatPath: true }}>
      <Home />
    </MemoryRouter>,
  );
}

describe('Home', () => {
  it('renders the heading', () => {
    renderHome();
    expect(screen.getByRole('heading', { name: /Home/i })).toBeInTheDocument();
  });

  it('renders the description text', () => {
    renderHome();
    expect(screen.getByText(/plugins are available/i)).toBeInTheDocument();
  });
});
