import React, { Suspense } from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';

// Import the home page
import Home from './pages/Home.tsx';

// Dynamically import all plugins under the ui‑plugins folder.  The
// glob pattern walks up two directories from this file into the
// top‑level `ui‑plugins` folder.  Each key in the returned object is
// the file path and the value is a function that returns a promise
// resolving to the module.  See Vite docs for details.
const modules = import.meta.glob('../../ui-plugins/**/index.tsx');

// Build plugin routes by mapping each plugin folder to a route.  The
// path is derived from the folder name (e.g.
// '../../ui-plugins/hello/index.tsx' → '/hello').  Each plugin is
// loaded lazily using React.lazy for optimal performance.
const pluginRoutes = Object.entries(modules).map(([path, loader]) => {
  // Extract the plugin name between 'ui-plugins/' and '/index.tsx'
  const match = /ui-plugins\/(.+?)\/index\.tsx$/.exec(path);
  const name = match ? match[1] : path;
  // Cast the loader to the correct type for React.lazy
  const Component = React.lazy(loader as unknown as () => Promise<{ default: React.ComponentType<any> }>);
  return { path: `/${name}`, Component };
});

export default function App() {
  return (
    <BrowserRouter future={{ v7_startTransition: true, v7_relativeSplatPath: true }}>
      {/* Suspense boundary to show fallback while lazy components load */}
      <Suspense fallback={<div>Loading...</div>}>
        <Routes>
          {/* Home route */}
          <Route path="/" element={<Home />} />
          {/* Dynamically generated plugin routes */}
          {pluginRoutes.map(({ path, Component }) => (
            <Route key={path} path={path} element={<Component />} />
          ))}
          {/* Catch‑all route for 404s */}
          <Route path="*" element={<div>Not Found</div>} />
        </Routes>
      </Suspense>
    </BrowserRouter>
  );
}