import { render, screen } from '@testing-library/react';
import { describe, it, expect } from 'vitest';
import App from '../App.tsx';

describe('App', () => {
  it('renders the home page at /', async () => {
    render(<App />);
    expect(await screen.findByRole('heading', { name: /Home/i })).toBeInTheDocument();
  });

  it('renders Not Found for unknown routes', async () => {
    // Set the URL before rendering
    window.history.pushState({}, '', '/unknown-route');
    render(<App />);
    expect(await screen.findByText(/Not Found/i)).toBeInTheDocument();
    // Reset URL
    window.history.pushState({}, '', '/');
  });
});
