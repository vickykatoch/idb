// Vitest setup file
//
// This file is executed before running any tests.  We extend the
// assertions available in Vitest by importing the jest‑dom matchers.
// These matchers provide convenient assertions like
// `toBeInTheDocument()` for testing DOM elements.

import '@testing-library/jest-dom';
