import { render, screen } from '@testing-library/react';
import { describe, it, expect } from 'vitest';
import VanillaLayout from '../VanillaLayout.tsx';

describe('VanillaLayout', () => {
  it('renders children', () => {
    render(
      <VanillaLayout>
        <p>Test content</p>
      </VanillaLayout>,
    );
    expect(screen.getByText('Test content')).toBeInTheDocument();
  });
});
