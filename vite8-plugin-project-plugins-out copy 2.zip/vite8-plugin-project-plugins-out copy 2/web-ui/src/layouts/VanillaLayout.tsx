import React from 'react';

interface VanillaLayoutProps {
  children: React.ReactNode;
}

export default function VanillaLayout({ children }: VanillaLayoutProps) {
  return (
    <div>
      {children}
    </div>
  );
}
