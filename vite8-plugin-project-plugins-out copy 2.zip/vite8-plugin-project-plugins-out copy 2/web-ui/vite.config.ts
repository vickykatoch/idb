/// <reference types="vitest/config" />
import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import { fileURLToPath } from 'url';
import { dirname, resolve } from 'path';

// Compute __dirname in ESM so we can resolve the ui‑plugins folder.  Vite
// will use these paths to allow serving files outside of the project
// root via server.fs.allow.
const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

// Vite configuration for the web UI
export default defineConfig({
  plugins: [react()],
  resolve: {
    tsconfigPaths: true,
    // Force all React imports (including those from ui‑plugins outside
    // this package) to resolve to the single copy inside web‑ui.
    // Without this, Vite may pick up a different React version from the
    // monorepo root node_modules, causing the "Invalid hook call" error.
    dedupe: ['react', 'react-dom'],
  },
  server: {
    // Forward browser console logs to the terminal, useful for AI debugging
    forwardConsole: true,
    fs: {
      // Allow serving modules from the parent directory (the monorepo root)
      // and the ui‑plugins folder.  Without this, Vite will block
      // imports that traverse outside of the project root【981453169940088†L32-L49】.
      allow: [
        // allow the parent of web-ui (the monorepo root)
        resolve(__dirname, '..'),
        // explicitly allow the ui‑plugins folder
        resolve(__dirname, '..', 'ui-plugins'),
      ],
    },
  },
  // Vitest configuration is placed inside the Vite config.  Vitest reads
  // this section automatically【637288399974810†L271-L279】 and reuses the Vite
  // plugins and resolve options.  See vitest docs for more information.
  test: {
    // enable Jest-like global test APIs (describe, it, expect)
    globals: true,
    // Use jsdom to simulate the DOM in unit tests.  This allows us to
    // render React components without a real browser.
    environment: 'jsdom',
    // Include test files from both the ui‑plugins folder and the src
    // directory.  Vitest will match files ending in .test.tsx or .spec.tsx.
    include: [
      '../ui-plugins/**/__tests__/*.test.{ts,tsx}',
      'src/**/__tests__/*.test.{ts,tsx}',
    ],
    // Setup file for configuring the test environment (e.g. jest-dom matchers)
    setupFiles: ['src/setupTests.ts'],
  },
});