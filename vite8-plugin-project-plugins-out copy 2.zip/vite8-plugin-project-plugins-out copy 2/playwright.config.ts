import { defineConfig } from '@playwright/test';

// Playwright configuration for end‑to‑end tests.
//
// We run the dev server before executing tests.  The `webServer` option
// starts the server using the provided command and waits until the
// specified URL responds.  Setting `reuseExistingServer` to true allows
// reusing an already running dev server when you iterate locally.  See
// Playwright documentation for more details.

export default defineConfig({
  // Directory where end‑to‑end tests live
  testDir: 'tests/e2e',
  // Run tests in parallel across available browsers
  fullyParallel: true,
  // Configure the local dev server for the UI
  webServer: {
    command: 'npm run dev',
    url: 'http://localhost:5173',
    reuseExistingServer: true,
    timeout: 120 * 1000,
  },
});